from flask import Flask, render_template, request, redirect, session
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'super-secret-key'

# Create DB if not exists
def init_db():
    if not os.path.exists('bhoomi.db'):
        conn = sqlite3.connect('bhoomi.db')
        c = conn.cursor()
        c.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()

init_db()

@app.route('/')
def home():
    return redirect('/login')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect('bhoomi.db')
        c = conn.cursor()
        try:
            c.execute('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', (name, email, password))
            conn.commit()
        except sqlite3.IntegrityError:
            return "⚠️ Email already registered!"
        finally:
            conn.close()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect('bhoomi.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password))
        user = c.fetchone()
        conn.close()

        if user:
            session['user_id'] = user[0]
            session['name'] = user[1]
            return redirect('/dashboard')
        else:
            return "❌ Invalid credentials!"
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')
    
    # Simulated soil data
    data = {
        "Nitrogen (N)": "82 mg/kg",
        "Phosphorus (P)": "47 mg/kg",
        "Potassium (K)": "62 mg/kg",
        "pH": "6.5",
        "Moisture": "34 %",
        "Temperature": "27.5 °C",
        "EC": "420 µS/cm"
    }

    tooltips = {
        "Nitrogen (N)": "Helps leafy growth and photosynthesis.",
        "Phosphorus (P)": "Essential for root development.",
        "Potassium (K)": "Improves drought resistance and crop quality.",
        "pH": "Affects nutrient absorption, ideal 6-7.5.",
        "Moisture": "Reflects water retention of the soil.",
        "Temperature": "Ideal for microbial activity in soil.",
        "EC": "Indicates soil salinity affecting root health."
    }

    return render_template('dashboard.html', name=session['name'], data=data, tooltips=tooltips)


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

if __name__ == '__main__':
    app.run(debug=True)
